## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# knitr::include_graphics("renv.png", dpi = 144)

## -----------------------------------------------------------------------------
# root <- renv::paths$root()
# unlink(root, recursive = TRUE)

